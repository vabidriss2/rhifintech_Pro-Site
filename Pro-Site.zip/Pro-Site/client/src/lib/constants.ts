
import { Activity, CreditCard, ShieldCheck, Heart, TrendingUp, Users } from "lucide-react";

export const TRANSLATIONS = {
  en: {
    nav: {
      brand: "RWANDA VANTAGE",
      home: "Home",
      features: "How it Works",
      dashboard: "Agent Dashboard",
      contact: "Contact",
    },
    hero: {
      title: "Health-Informed Financial Inclusion",
      subtitle: "Empowering Rwanda's unbanked population by turning health responsibility into financial opportunity.",
      cta: "Launch Prototype",
      secondary_cta: "Learn More",
    },
    features: {
      title: "The HIFinTech Ecosystem",
      subtitle: "A secure microservices architecture connecting health and finance.",
      items: [
        {
          title: "Health Indicators API (HIA)",
          desc: "Securely aggregates adherence data (0-100 score) without revealing private medical details.",
          icon: Heart,
        },
        {
          title: "Credit Scoring API (CSA)",
          desc: "Advanced ML algorithms combining financial behavior with health responsibility metrics.",
          icon: TrendingUp,
        },
        {
          title: "Consent Manager",
          desc: "Transparent, token-based consent system ensuring user control over their data.",
          icon: ShieldCheck,
        },
      ],
    },
    agent_dashboard: {
      title: "Agent Dashboard",
      subtitle: "IMF Credit Assessment Portal",
      tabs: {
        new_app: "New Application",
        simulator: "Risk Simulator",
        history: "Application History"
      },
      form: {
        steps: {
          identify: "Client Identification",
          loan: "Loan Details",
          assessment: "Risk Assessment",
          result: "Final Decision"
        },
        fields: {
          nid: "National ID / NID",
          phone: "Phone Number",
          firstname: "First Name",
          lastname: "Last Name",
          amount: "Loan Amount (RWF)",
          duration: "Duration (Months)",
          purpose: "Purpose of Loan",
          income: "Monthly Income (Declared)"
        },
        actions: {
          search: "Search Client",
          next: "Next Step",
          back: "Back",
          submit: "Calculate Score",
          request_consent: "Request Health Data Consent",
          consent_sent: "Consent Request Sent via SMS"
        },
        status: {
          consent_needed: "Health Data Consent Missing",
          consent_valid: "Consent Validated (Token: #HIA-OK)",
          fetching: "Retrieving external data..."
        }
      }
    },
    simulator: {
      title: "Credit Scoring Simulator",
      subtitle: "Demonstration for IMF Agents: Adjust variables to see how health impacts credit risk.",
      inputs: {
        financial: "Financial History (Mobile Money)",
        health: "Health Adherence Score (HIA)",
        demographics: "Demographic Stability",
      },
      result: {
        score: "VANTAGE SCORE",
        status: "Loan Eligibility",
        approved: "APPROVED",
        rejected: "NEEDS IMPROVEMENT",
        rate: "Interest Rate Modifier",
      },
    },
    assistant: {
      title: "Vantage AI Assistant",
      welcome: "Muraho! I am your Vantage Assistant. How can I help you interpret this score?",
      placeholder: "Ask about the score or health advice...",
    },
    roles: {
      title: "Choose Your Portal",
      subtitle: "Login to the specific workspace for your role",
      agent: {
        title: "IMF Agent",
        desc: "Process loan applications and analyze credit scores.",
        cta: "Agent Access"
      },
      client: {
        title: "Client (Borrower)",
        desc: "View personal score, manage consent, and see loan offers.",
        cta: "Client Access"
      },
      admin: {
        title: "System Admin",
        desc: "Monitor system performance, API status, and global statistics.",
        cta: "Admin Access"
      }
    },
    client_portal: {
      title: "My Client Space",
      health_score: "My Health Score",
      consent_title: "Data Consent Settings",
      consent_desc: "I authorize access to my aggregated health adherence score to improve my loan rates.",
      offers: "Loan Offers",
      status_active: "Active",
      status_pending: "Pending"
    },
    admin_portal: {
      title: "Admin Overview",
      stats: {
        users: "Total Users",
        loans: "Active Loans",
        health_impact: "Health/Repayment Correlation"
      }
    }
  },
  fr: {
    nav: {
      brand: "RWANDA VANTAGE",
      home: "Accueil",
      features: "Comment ça marche",
      dashboard: "Tableau de Bord Agent",
      contact: "Contact",
    },
    hero: {
      title: "Inclusion Financière par la Santé",
      subtitle: "Autonomiser la population non bancarisée du Rwanda en transformant la responsabilité sanitaire en opportunité financière.",
      cta: "Lancer le Prototype",
      secondary_cta: "En Savoir Plus",
    },
    features: {
      title: "L'Écosystème HIFinTech",
      subtitle: "Une architecture de microservices sécurisée reliant la santé et la finance.",
      items: [
        {
          title: "API Indicateurs Santé (HIA)",
          desc: "Agrège en toute sécurité les données d'adhérence (score 0-100) sans révéler de détails médicaux.",
          icon: Heart,
        },
        {
          title: "API Scoring Crédit (CSA)",
          desc: "Algorithmes ML avancés combinant comportement financier et métriques de responsabilité santé.",
          icon: TrendingUp,
        },
        {
          title: "Gestionnaire de Consentement",
          desc: "Système de consentement transparent basé sur des jetons assurant le contrôle utilisateur.",
          icon: ShieldCheck,
        },
      ],
    },
    agent_dashboard: {
      title: "Tableau de Bord Agent",
      subtitle: "Portail d'Évaluation de Crédit IMF",
      tabs: {
        new_app: "Nouvelle Demande",
        simulator: "Simulateur de Risque",
        history: "Historique"
      },
      form: {
        steps: {
          identify: "Identification Client",
          loan: "Détails du Prêt",
          assessment: "Évaluation des Risques",
          result: "Décision Finale"
        },
        fields: {
          nid: "ID National / NID",
          phone: "Numéro de Téléphone",
          firstname: "Prénom",
          lastname: "Nom",
          amount: "Montant (RWF)",
          duration: "Durée (Mois)",
          purpose: "Motif du Prêt",
          income: "Revenu Mensuel (Déclaré)"
        },
        actions: {
          search: "Rechercher Client",
          next: "Suivant",
          back: "Retour",
          submit: "Calculer le Score",
          request_consent: "Demander Consentement Santé",
          consent_sent: "Demande envoyée par SMS"
        },
        status: {
          consent_needed: "Consentement Données Santé Manquant",
          consent_valid: "Consentement Validé (Token: #HIA-OK)",
          fetching: "Récupération des données externes..."
        }
      }
    },
    simulator: {
      title: "Simulateur de Scoring Crédit",
      subtitle: "Démonstration pour Agents IMF : Ajustez les variables pour voir l'impact de la santé.",
      inputs: {
        financial: "Historique Financier (Mobile Money)",
        health: "Score d'Adhérence Santé (HIA)",
        demographics: "Stabilité Démographique",
      },
      result: {
        score: "SCORE VANTAGE",
        status: "Éligibilité au Prêt",
        approved: "APPROUVÉ",
        rejected: "À AMÉLIORER",
        rate: "Modificateur de Taux",
      },
    },
    assistant: {
      title: "Assistant IA Vantage",
      welcome: "Muraho! Je suis votre Assistant Vantage. Comment puis-je vous aider à interpréter ce score ?",
      placeholder: "Posez une question sur le score...",
    },
    roles: {
      title: "Choisissez votre Accès",
      subtitle: "Connectez-vous au portail dédié à votre rôle",
      agent: {
        title: "Agent IMF",
        desc: "Gérer les demandes de prêts et analyser les scores de crédit.",
        cta: "Accès Agent"
      },
      client: {
        title: "Client (Emprunteur)",
        desc: "Voir mon score, gérer mes consentements et mes offres.",
        cta: "Accès Client"
      },
      admin: {
        title: "Administrateur",
        desc: "Superviser les performances du système et les statistiques.",
        cta: "Accès Admin"
      }
    },
    client_portal: {
      title: "Mon Espace Client",
      health_score: "Mon Score Santé",
      consent_title: "Gestion du Consentement",
      consent_desc: "J'autorise l'accès à mon score d'adhérence santé pour améliorer mon taux de crédit.",
      offers: "Offres de Prêt",
      status_active: "Active",
      status_pending: "En Attente"
    },
    admin_portal: {
      title: "Tableau de Bord Admin",
      stats: {
        users: "Utilisateurs Actifs",
        loans: "Prêts Accordés",
        health_impact: "Impact Santé/Remboursement"
      }
    }
  },
  rw: {
    nav: {
      brand: "RWANDA VANTAGE",
      home: "Ahabanza",
      features: "Imikorere",
      dashboard: "Urubuga rw'Umukozi",
      contact: "Tuvugishe",
    },
    hero: {
      title: "Imari N'Ubuzima",
      subtitle: "Gufasha abanyarwanda kubona serivisi z'imari binyuze mu kwita ku buzima bwabo.",
      cta: "Tangira",
      secondary_cta: "Soma Byinshi",
    },
    features: {
      title: "Ikoranabuhanga rya HIFinTech",
      subtitle: "Ihuza serivisi z'imari n'iz'ubuzima mu buryo bwizewe.",
      items: [
        {
          title: "Ibipimo by'Ubuzima (HIA)",
          desc: "Kusanya amakuru y'ubuzima (amanota 0-100) hatamenyekanye amakuru yihariye.",
          icon: Heart,
        },
        {
          title: "Amanota y'Inguzanyo (CSA)",
          desc: "Ikoranabuhanga rihuza imyitwarire mu by'imari n'ubuzima.",
          icon: TrendingUp,
        },
        {
          title: "Uruhushya rw'Umukiriya",
          desc: "Uburyo bworoshye bwo gutanga uburenganzira ku makuru yawe.",
          icon: ShieldCheck,
        },
      ],
    },
    agent_dashboard: {
      title: "Urubuga rw'Umukozi",
      subtitle: "Isesengura ry'Inguzanyo",
      tabs: {
        new_app: "Gusaba Inguzanyo",
        simulator: "Simulateri",
        history: "Amateka"
      },
      form: {
        steps: {
          identify: "Kumenyekanisha Umukiriya",
          loan: "Amakuru y'Inguzanyo",
          assessment: "Isesengura ry'Ingaruka",
          result: "Umwanzuro"
        },
        fields: {
          nid: "Indangamuntu",
          phone: "Nimero ya Telefoni",
          firstname: "Izina",
          lastname: "Irindi Zina",
          amount: "Amafaranga (RWF)",
          duration: "Igihe (Amezi)",
          purpose: "Impamvu y'Inguzanyo",
          income: "Umushahara"
        },
        actions: {
          search: "Shaka Umukiriya",
          next: "Komeza",
          back: "Subira Inyuma",
          submit: "Kubara Amanota",
          request_consent: "Gusaba Uruhushya rw'Amakuru y'Ubuzima",
          consent_sent: "Ubutumwa bwoherejwe kuri SMS"
        },
        status: {
          consent_needed: "Uruhushya rw'Amakuru y'Ubuzima rurabuze",
          consent_valid: "Uruhushya Rwemewe (Token: #HIA-OK)",
          fetching: "Gukura amakuru hanze..."
        }
      }
    },
    simulator: {
      title: "Simulateri y'Amanota",
      subtitle: "Iyerekanwa ry'Abakozi ba IMF: Hindura ibipimo urebe ingaruka ku nguzanyo.",
      inputs: {
        financial: "Amateka y'Imari (Mobile Money)",
        health: "Amanota y'Ubuzima (HIA)",
        demographics: "Imibereho",
      },
      result: {
        score: "AMANOTA VANTAGE",
        status: "Kwemererwa Inguzanyo",
        approved: "BYEMWEWE",
        rejected: "BISABA KUNONOSORA",
        rate: "Inyungu",
      },
    },
    assistant: {
      title: "Vantage Assistant",
      welcome: "Muraho! Ndi umufasha wawe wa Vantage. Nagufasha nte gusobanukirwa aya manota?",
      placeholder: "Baza ikibazo...",
    },
    roles: {
      title: "Hitamo Uruhare Rwawe",
      subtitle: "Injira mu rubuga ukurikije inshingano zawe",
      agent: {
        title: "Umukozi wa IMF",
        desc: "Kora isesengura ry'inguzanyo n'amanota y'abakiriya.",
        cta: "Injira nka Agent"
      },
      client: {
        title: "Umukiriya (Ushaka Inguzanyo)",
        desc: "Reba amanota yawe, tanga uruhushya rwo gusangira amakuru.",
        cta: "Injira nka Client"
      },
      admin: {
        title: "Umuyobozi (Admin)",
        desc: "Kurikirana imikorere ya sisitemu n'ibipimo byose.",
        cta: "Injira nka Admin"
      }
    },
    client_portal: {
      title: "Konti Yanjye",
      health_score: "Amanota Y'Ubuzima",
      consent_title: "Uruhushya rwo Gusangira Amakuru",
      consent_desc: "Nemereye banki kureba amanota yanjye y'ubuzima kugira ngo mpabwe inyungu ntoya.",
      offers: "Inguzanyo Uwemerewe",
      status_active: "Iremewe",
      status_pending: "Itegereje"
    },
    admin_portal: {
      title: "Urubuga rw'Umuyobozi",
      stats: {
        users: "Abakiriya Bose",
        loans: "Inguzanyo Zitanze",
        health_impact: "Ingaruka z'Ubuzima ku Kwishyura"
      }
    }
  },
};
