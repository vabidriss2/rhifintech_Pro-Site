import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { TRANSLATIONS } from "@/lib/constants";
import heroImage from "@assets/generated_images/rwandan_entrepreneur_using_fintech_app.png";

interface HeroProps {
  lang: "en" | "fr" | "rw";
}

export default function Hero({ lang }: HeroProps) {
  const t = TRANSLATIONS[lang].hero;

  return (
    <section className="relative overflow-hidden bg-background py-20 md:py-32 lg:py-40">
      <div className="container px-4 md:px-6">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="flex flex-col justify-center space-y-8"
          >
            <div className="space-y-4">
              <div className="inline-flex items-center rounded-full border px-3 py-1 text-sm font-medium text-secondary bg-secondary/10">
                <span className="flex h-2 w-2 rounded-full bg-secondary mr-2 animate-pulse"></span>
                RWANDA VANTAGE PILOT 2025
              </div>
              <h1 className="text-4xl font-display font-bold tracking-tighter sm:text-5xl xl:text-7xl/none text-foreground">
                {t.title}
              </h1>
              <p className="max-w-[600px] text-muted-foreground md:text-xl font-light leading-relaxed">
                {t.subtitle}
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/dashboard">
                <Button size="lg" className="h-12 px-8 text-lg bg-primary hover:bg-primary/90 text-white shadow-lg hover:shadow-xl transition-all">
                  {t.cta}
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="h-12 px-8 text-lg border-primary/20 hover:bg-primary/5">
                {t.secondary_cta}
              </Button>
            </div>

            <div className="flex items-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-secondary" />
                <span>GDPR Compliant</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-secondary" />
                <span>Secure HIA API</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-secondary" />
                <span>AI-Powered</span>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative lg:ml-auto"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border border-border/50 aspect-video lg:aspect-square max-h-[600px] w-full group">
               <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent mix-blend-overlay z-10 pointer-events-none"></div>
               <img 
                 src={heroImage} 
                 alt="Rwandan Entrepreneur" 
                 className="object-cover w-full h-full transition-transform duration-700 group-hover:scale-105"
               />
               
               {/* Floating Badge */}
               <div className="absolute bottom-6 left-6 right-6 z-20">
                 <div className="bg-background/90 backdrop-blur-md p-4 rounded-xl shadow-lg border border-border/50 flex items-center justify-between">
                   <div>
                     <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Credit Score</p>
                     <p className="text-2xl font-bold text-primary font-display">785 <span className="text-sm font-normal text-secondary">(+45)</span></p>
                   </div>
                   <div className="h-10 w-10 rounded-full bg-secondary/20 flex items-center justify-center">
                     <CheckCircle2 className="h-6 w-6 text-secondary" />
                   </div>
                 </div>
               </div>
            </div>
            
            {/* Decorative background blob */}
            <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-primary/5 rounded-full blur-3xl"></div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
