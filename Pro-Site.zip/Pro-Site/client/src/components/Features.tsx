import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { TRANSLATIONS } from "@/lib/constants";
import archiImage from "@assets/generated_images/abstract_fintech_health_data_visualization.png";

interface FeaturesProps {
  lang: "en" | "fr" | "rw";
}

export default function Features({ lang }: FeaturesProps) {
  const t = TRANSLATIONS[lang].features;

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <section id="features" className="py-20 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-3xl font-display font-bold tracking-tight sm:text-4xl md:text-5xl text-primary">
            {t.title}
          </h2>
          <p className="mx-auto max-w-[700px] text-muted-foreground md:text-lg">
            {t.subtitle}
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
           {/* Conceptual Diagram */}
           <motion.div 
             initial={{ opacity: 0, x: -20 }}
             whileInView={{ opacity: 1, x: 0 }}
             viewport={{ once: true }}
             className="relative rounded-2xl overflow-hidden shadow-xl border border-border bg-white p-2"
           >
             <img 
               src={archiImage} 
               alt="Architecture Diagram" 
               className="w-full h-auto rounded-xl"
             />
             <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="bg-background/80 backdrop-blur-sm px-6 py-3 rounded-full border shadow-sm">
                  <p className="font-mono text-sm text-primary font-semibold">Architecture: Microservices</p>
                </div>
             </div>
           </motion.div>

           {/* Features List */}
           <motion.div 
             variants={container}
             initial="hidden"
             whileInView="show"
             viewport={{ once: true }}
             className="grid gap-6"
           >
             {t.items.map((feature, index) => {
               const Icon = feature.icon;
               return (
                 <motion.div key={index} variants={item}>
                   <Card className="border-l-4 border-l-primary hover:shadow-lg transition-shadow">
                     <CardHeader className="flex flex-row items-start gap-4 space-y-0 pb-2">
                       <div className="mt-1 h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                         <Icon className="h-5 w-5 text-primary" />
                       </div>
                       <div className="space-y-1">
                         <CardTitle className="text-xl font-bold text-foreground">
                           {feature.title}
                         </CardTitle>
                         <CardDescription className="text-base leading-relaxed">
                           {feature.desc}
                         </CardDescription>
                       </div>
                     </CardHeader>
                   </Card>
                 </motion.div>
               );
             })}
           </motion.div>
        </div>
      </div>
    </section>
  );
}
