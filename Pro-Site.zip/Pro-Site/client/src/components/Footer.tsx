export default function Footer() {
  return (
    <footer className="bg-foreground text-primary-foreground py-12">
      <div className="container px-4 md:px-6">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-display text-xl font-bold mb-4">RWANDA VANTAGE</h3>
            <p className="text-sm text-primary-foreground/70 leading-relaxed">
              Empowering financial inclusion through health responsibility. 
              A Final Year Project proposition for 2025.
            </p>
          </div>
          <div>
            <h4 className="font-bold mb-4 text-sm uppercase tracking-wider text-secondary">Project Pillars</h4>
            <ul className="space-y-2 text-sm text-primary-foreground/70">
              <li>Health Indicators API</li>
              <li>Credit Scoring AI</li>
              <li>Financial Inclusion</li>
              <li>Data Privacy (GDPR)</li>
            </ul>
          </div>
          <div>
            <h4 className="font-bold mb-4 text-sm uppercase tracking-wider text-secondary">Contact</h4>
            <p className="text-sm text-primary-foreground/70 mb-2">University of Rwanda / Kepler</p>
            <p className="text-sm text-primary-foreground/70">student@university.rw</p>
          </div>
        </div>
        <div className="border-t border-primary-foreground/10 mt-8 pt-8 text-center text-xs text-primary-foreground/50">
          © 2025 Rwanda Vantage Project. Prototype Version 1.0.0
        </div>
      </div>
    </footer>
  );
}
