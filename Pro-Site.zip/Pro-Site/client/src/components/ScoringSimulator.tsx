import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { AlertCircle, CheckCircle, TrendingUp, User, Wallet } from "lucide-react";
import { TRANSLATIONS } from "@/lib/constants";

interface ScoringSimulatorProps {
  lang: "en" | "fr" | "rw";
}

export default function ScoringSimulator({ lang }: ScoringSimulatorProps) {
  const t = TRANSLATIONS[lang].simulator;
  
  // State for inputs
  const [financialScore, setFinancialScore] = useState(50);
  const [healthScore, setHealthScore] = useState(50);
  const [demoScore, setDemoScore] = useState(50);
  
  // Derived state for result
  const [finalScore, setFinalScore] = useState(0);
  const [status, setStatus] = useState<"approved" | "rejected">("rejected");
  const [interestRate, setInterestRate] = useState(15); // Base rate 15%

  // Calculate score whenever inputs change
  useEffect(() => {
    // Formula from proposal: Score = a1(Finance) + a2(Health) + a3(Demo)
    // Let's assume weights: Finance 40%, Health 40%, Demo 20% to show impact of Health
    const weightedScore = (financialScore * 0.4) + (healthScore * 0.4) + (demoScore * 0.2);
    setFinalScore(Math.round(weightedScore));
    
    // Determine status and rate
    if (weightedScore >= 65) {
      setStatus("approved");
      // Higher score = lower rate. Min 8%, Max 15%
      const reduction = Math.floor((weightedScore - 60) / 5); 
      setInterestRate(Math.max(8, 15 - reduction));
    } else {
      setStatus("rejected");
      setInterestRate(15);
    }
  }, [financialScore, healthScore, demoScore]);

  return (
    <div className="grid lg:grid-cols-12 gap-8 h-full">
      {/* Input Panel */}
      <Card className="lg:col-span-7 h-fit border-t-4 border-t-primary shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-2xl">
            <TrendingUp className="h-6 w-6 text-primary" />
            {t.title}
          </CardTitle>
          <CardDescription>{t.subtitle}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-8 py-6">
          
          {/* Financial Input */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label className="text-base font-semibold flex items-center gap-2">
                <Wallet className="h-4 w-4 text-muted-foreground" />
                {t.inputs.financial}
              </Label>
              <span className="font-mono text-primary font-bold">{financialScore}/100</span>
            </div>
            <Slider 
              value={[financialScore]} 
              onValueChange={(vals) => setFinancialScore(vals[0])} 
              max={100} 
              step={1}
              className="py-4"
            />
            <p className="text-xs text-muted-foreground">Based on Mobile Money history transparency and repayment frequency.</p>
          </div>

          {/* Health Input - Highlighted */}
          <div className="space-y-4 bg-secondary/5 p-4 rounded-xl border border-secondary/20">
            <div className="flex justify-between items-center">
              <Label className="text-base font-semibold flex items-center gap-2 text-secondary-foreground/80">
                <ActivityIcon className="h-4 w-4 text-secondary" />
                {t.inputs.health}
              </Label>
              <span className="font-mono text-secondary font-bold">{healthScore}/100</span>
            </div>
            <Slider 
              value={[healthScore]} 
              onValueChange={(vals) => setHealthScore(vals[0])} 
              max={100} 
              step={1}
              className="py-4 [&_.bg-primary]:bg-secondary" // Override slider color
            />
            <p className="text-xs text-muted-foreground">Aggregated adherence to treatments and preventative check-ups (HIA API).</p>
          </div>

          {/* Demographics Input */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label className="text-base font-semibold flex items-center gap-2">
                <User className="h-4 w-4 text-muted-foreground" />
                {t.inputs.demographics}
              </Label>
              <span className="font-mono text-primary font-bold">{demoScore}/100</span>
            </div>
            <Slider 
              value={[demoScore]} 
              onValueChange={(vals) => setDemoScore(vals[0])} 
              max={100} 
              step={1}
              className="py-4"
            />
          </div>

        </CardContent>
      </Card>

      {/* Result Panel */}
      <Card className={`lg:col-span-5 flex flex-col justify-center transition-colors duration-500 ${status === 'approved' ? 'bg-secondary/10 border-secondary' : 'bg-destructive/5 border-destructive'}`}>
        <CardHeader className="text-center pb-2">
          <CardTitle className="text-sm font-medium uppercase tracking-widest text-muted-foreground">
            {t.result.score}
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col items-center space-y-6 text-center">
          
          <div className="relative flex items-center justify-center h-48 w-48">
            {/* Circular Progress */}
            <svg className="absolute w-full h-full transform -rotate-90">
              <circle
                cx="96"
                cy="96"
                r="80"
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                className="text-muted/20"
              />
              <motion.circle
                cx="96"
                cy="96"
                r="80"
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                strokeDasharray={2 * Math.PI * 80}
                strokeDashoffset={2 * Math.PI * 80 * (1 - finalScore / 100)}
                className={status === 'approved' ? "text-secondary" : "text-destructive"}
                initial={{ strokeDashoffset: 2 * Math.PI * 80 }}
                animate={{ strokeDashoffset: 2 * Math.PI * 80 * (1 - finalScore / 100) }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                strokeLinecap="round"
              />
            </svg>
            <div className="flex flex-col items-center">
              <span className={`text-6xl font-display font-bold ${status === 'approved' ? "text-secondary" : "text-destructive"}`}>
                {finalScore}
              </span>
              <span className="text-sm font-medium text-muted-foreground">/ 100</span>
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-lg font-medium text-foreground">{t.result.status}</h3>
            <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full font-bold text-sm ${status === 'approved' ? "bg-secondary text-white" : "bg-destructive text-white"}`}>
              {status === 'approved' ? <CheckCircle className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
              {status === 'approved' ? t.result.approved : t.result.rejected}
            </div>
          </div>

          {status === 'approved' && (
             <div className="w-full pt-4 border-t border-border/50">
               <div className="flex justify-between items-center px-4">
                 <span className="text-sm text-muted-foreground">{t.result.rate}</span>
                 <span className="text-xl font-bold text-primary">{interestRate}%</span>
               </div>
             </div>
          )}

        </CardContent>
      </Card>
    </div>
  );
}

function ActivityIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
    </svg>
  );
}
