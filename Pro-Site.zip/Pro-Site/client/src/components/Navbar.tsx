import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Globe, LogOut, LayoutDashboard } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { TRANSLATIONS } from "@/lib/constants";

type Language = "en" | "fr" | "rw";

interface NavbarProps {
  lang: Language;
  setLang: (lang: Language) => void;
}

export default function Navbar({ lang, setLang }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const t = TRANSLATIONS[lang].nav;

  const isActive = (path: string) => location === path;
  
  // Check if we are in a portal (dashboard)
  const isPortal = location === "/dashboard" || location === "/client" || location === "/admin";
  const portalName = location === "/dashboard" ? "Agent Portal" : 
                     location === "/client" ? "Client Portal" : 
                     location === "/admin" ? "Admin Portal" : "";

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md no-print">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex h-16 items-center justify-between">
          <Link href="/">
            <a className="flex items-center gap-2 font-display text-xl font-bold tracking-tighter text-primary">
              <span className="text-2xl">🇷🇼</span>
              {t.brand}
              {isPortal && (
                <span className="hidden sm:inline-flex ml-2 text-sm font-normal text-muted-foreground border-l pl-2">
                   {portalName}
                </span>
              )}
            </a>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-6">
            {!isPortal ? (
              <>
                <Link href="/">
                  <a className={`text-sm font-medium transition-colors hover:text-primary ${isActive("/") ? "text-primary" : "text-muted-foreground"}`}>
                    {t.home}
                  </a>
                </Link>
                <a href="/#features" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">
                  {t.features}
                </a>
                
                <Link href="/login">
                  <Button size="sm" variant="outline" className={`border-primary/20 hover:bg-primary/5 ${isActive("/login") ? "bg-primary/5" : ""}`}>
                    {lang === 'rw' ? 'Injira' : lang === 'fr' ? 'Connexion' : 'Login Portals'}
                  </Button>
                </Link>
              </>
            ) : (
              <div className="flex items-center gap-4">
                 <span className="text-sm text-muted-foreground">Logged in as {location === "/admin" ? "Admin" : location === "/client" ? "Jean-Paul M." : "Agent 007"}</span>
                 <Link href="/login">
                   <Button size="sm" variant="ghost" className="text-destructive hover:bg-destructive/10">
                     <LogOut className="h-4 w-4 mr-2" />
                     Logout
                   </Button>
                 </Link>
              </div>
            )}
            
            <div className="ml-4 flex items-center gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Globe className="h-4 w-4" />
                    <span className="sr-only">Toggle language</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => setLang("en")}>🇬🇧 English</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLang("fr")}>🇫🇷 Français</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLang("rw")}>🇷🇼 Kinyarwanda</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              {!isPortal && (
                <Button size="sm" className="font-semibold bg-primary hover:bg-primary/90">
                  {t.contact}
                </Button>
              )}
            </div>
          </div>

          {/* Mobile Menu Toggle */}
          <div className="flex md:hidden items-center gap-4">
            <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Globe className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => setLang("en")}>🇬🇧 EN</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLang("fr")}>🇫🇷 FR</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setLang("rw")}>🇷🇼 RW</DropdownMenuItem>
                </DropdownMenuContent>
            </DropdownMenu>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-muted-foreground hover:text-foreground"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden border-t bg-background p-4">
          <div className="flex flex-col space-y-4">
            {!isPortal ? (
              <>
                <Link href="/">
                  <a className="text-sm font-medium text-foreground" onClick={() => setIsOpen(false)}>
                    {t.home}
                  </a>
                </Link>
                <a href="/#features" className="text-sm font-medium text-foreground" onClick={() => setIsOpen(false)}>
                  {t.features}
                </a>
                <Link href="/login">
                  <a className="text-sm font-medium text-foreground" onClick={() => setIsOpen(false)}>
                    {lang === 'rw' ? 'Injira' : lang === 'fr' ? 'Connexion' : 'Login Portals'}
                  </a>
                </Link>
                <Button className="w-full">{t.contact}</Button>
              </>
            ) : (
               <Link href="/login">
                 <Button variant="destructive" className="w-full">
                   <LogOut className="h-4 w-4 mr-2" />
                   Logout
                 </Button>
               </Link>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
