import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send, Bot, User } from "lucide-react";
import { TRANSLATIONS } from "@/lib/constants";
import botAvatar from "@assets/generated_images/friendly_ai_assistant_avatar.png";

interface AIAssistantProps {
  lang: "en" | "fr" | "rw";
}

type Message = {
  role: "user" | "bot";
  text: string;
};

// Simulated Knowledge Base
const KNOWLEDGE_BASE = {
  en: {
    vision: "RWANDA VANTAGE aligns with Vision 2050 by digitizing financial services and promoting a healthy population. It accelerates financial inclusion for unbanked citizens while incentivizing preventative healthcare, creating a socio-economic synergy.",
    architecture: "The system uses a Microservices Architecture with a secure API Gateway. It separates Health Data (HIA) from Financial Data (CSA) to ensure privacy. All health data is aggregated (0-100 score) before sharing, complying with data protection standards.",
    health: "As an E-Health Engineer, I designed the HIA API to NEVER share medical details. It only calculates an 'Adherence Score' based on appointment attendance and treatment compliance. This score is encrypted and tokenized for privacy.",
    model: "Our Credit Scoring Model combines: 1) Mobile Money history (payment regularity), 2) Health Adherence Score (responsibility proxy), and 3) Demographic stability. We use a Random Forest algorithm because it's interpretable and handles non-linear relationships well.",
    score_agent: "The 'Vantage Score' is a composite risk metric. A high Health Score (above 80) indicates responsible behavior, which statistically correlates with lower loan default rates. This allows you to offer lower interest rates to 'thin-file' clients.",
    score_client: "Your loan application is evaluated based on your financial history and your health responsibility. A high health score shows you are reliable! To improve your score: attend your check-ups and pay mobile bills on time.",
    prevention: "Your health score is slightly low. Reminder: Regular check-ups at your local Health Post are free and improve your score. Please finish your current malaria treatment course to boost your rating next month!",
    consent_expl: "Digital consent is like a digital signature giving us permission to view specific data to help you. We ONLY see a 'Health Score' (0-100) and your payment history. We NEVER see your medical records or specific illnesses. You are in control: you can stop sharing this data anytime by dialing *182# or visiting an agent.",
    ethics: "To ensure fairness, our model is 'Explainable by Design'. We use transparent algorithms (like Random Forest) rather than 'Black Boxes', allowing us to explain exactly why a score is high or low. We actively audit for bias to ensure that factors like gender or location do not negatively impact the score, focusing purely on behavioral reliability.",
    default: "I can answer questions about the Credit Model, Health API Security, Vision 2050 impact, Ethics, Consent, or help you interpret a specific client score."
  },
  fr: {
    vision: "RWANDA VANTAGE s'aligne sur la Vision 2050 en numérisant les services financiers et en promouvant une population en bonne santé. Il accélère l'inclusion financière tout en encourageant la santé préventive.",
    architecture: "Le système utilise une architecture Microservices avec une API Gateway sécurisée. Il sépare les données de santé (HIA) des données financières (CSA). Les données sont agrégées (score 0-100) avant partage.",
    health: "En tant qu'ingénieur e-santé, j'ai conçu l'API HIA pour NE JAMAIS partager de détails médicaux. Elle calcule uniquement un 'Score d'Adhérence' chiffré et tokenisé.",
    model: "Notre modèle combine : 1) Historique Mobile Money, 2) Score d'Adhérence Santé (responsabilité), 3) Stabilité démographique. Nous utilisons un algorithme Random Forest pour sa précision et son interprétabilité.",
    score_agent: "Le 'Score Vantage' est une mesure de risque composite. Un Score Santé élevé (>80) indique un comportement responsable, corrélé à un risque de défaut plus faible. Cela permet d'offrir de meilleurs taux.",
    score_client: "Votre demande est évaluée sur votre historique financier et votre responsabilité santé. Un bon score santé montre votre fiabilité ! Pour l'améliorer : respectez vos rendez-vous médicaux.",
    prevention: "Votre score santé est moyen. Rappel : Les visites au Poste de Santé sont bénéfiques pour votre score. Finissez votre traitement en cours pour gagner des points le mois prochain !",
    consent_expl: "Le consentement numérique est une permission que vous nous donnez pour voir certaines informations afin de vous aider. Nous voyons UNIQUEMENT un 'Score Santé' (0-100) et vos paiements. Nous ne voyons JAMAIS vos maladies. Vous pouvez retirer cette permission à tout moment via *182# ou chez un agent.",
    ethics: "Pour garantir l'équité, notre modèle est 'Explicable par Design'. Nous utilisons des algorithmes transparents pour expliquer chaque score. Nous auditons régulièrement les biais pour assurer que le genre ou la région n'influencent pas négativement le résultat, en nous concentrant uniquement sur la fiabilité.",
    default: "Je peux répondre aux questions sur le Modèle, la Sécurité, l'Éthique, le Consentement, Vision 2050, ou vous aider à interpréter un score."
  },
  rw: {
    vision: "RWANDA VANTAGE ijyanye na Vision 2050 mu guteza imbere ikoranabuhanga mu mari n'ubuzima. Ifasha abaturage kubona inguzanyo no kwita ku buzima bwabo.",
    architecture: "Iri koranabuhanga rikoresha Microservices. Ritandukanya amakuru y'ubuzima n'ay'imari kugira ngo amabanga y'abarwayi arindwe neza.",
    health: "Nka Injeniyeri w'ubuzima, nakoze API itanga amanota gusa (0-100) ntigaragaze indwara umuntu arwaye. Byose birarinzwe (Encrypted).",
    model: "Turahuza: 1) Imikoreshereze ya Mobile Money, 2) Amanota y'Ubuzima, 3) Aho utuye. Dukoresha ubwenge bw'ubukorano (AI) kugira ngo tubare neza.",
    score_agent: "Amanota ya Vantage agaragaza ubusembwa bw'umukiriya. Iyo afite amanota meza y'ubuzima (>80), bivuze ko ari inyangamugayo, bityo ahabwa inyungu ntoya.",
    score_client: "Inguzanyo yawe ishingiye ku mari no ku buzima. Kwivuza neza biguhesha amanota meza! Komeza kwitabira gahunda za muganga.",
    prevention: "Amanota yawe y'ubuzima aracyari hasi. Ibuka: Kwivuza ku gihe bituma amanota yiyongera. Rangiza imiti wahawe kugira ngo ukwezi gutaha uzabone amanota menshi!",
    consent_expl: "Uruhushya rw'ikoranabuhanga ni nko gusinya utanze uburenganzira bwo kureba amanota yawe. Tubona gusa 'Amanota y'Ubuzima' n'uko wishyura. Nta na rimwe tubona indwara urwaye. Ushobora guhagarika ubu burenganzira igihe cyose ukoresheje *182#.",
    ethics: "Kugira ngo habeho ubutabera, ikoranabuhanga ryacu rirasobanutse. Dukoresha uburyo butuma dusobanura impamvu amanota ari hejuru cyangwa hasi. Turagenzura cyane kugira ngo hatabaho kurenganya, twibanda gusa ku myitwarire y'umukiriya.",
    default: "Mbaza ibyerekeye Amanota, Umutekano w'Amakuru, Uruhushya, Ubutabera (Ethics) cyangwa Vision 2050."
  }
};

export default function AIAssistant({ lang }: AIAssistantProps) {
  const t = TRANSLATIONS[lang].assistant;
  const [messages, setMessages] = useState<Message[]>([
    { role: "bot", text: t.welcome }
  ]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isTyping, setIsTyping] = useState(false);

  useEffect(() => {
    // Reset welcome message on lang change
    setMessages([{ role: "bot", text: t.welcome }]);
  }, [lang]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, isTyping]);

  const getResponse = (query: string, language: "en" | "fr" | "rw") => {
    const q = query.toLowerCase();
    const kb = KNOWLEDGE_BASE[language];

    if (q.includes("vision") || q.includes("2050") || q.includes("econom") || q.includes("ben") || q.includes("bén") || q.includes("inyungu")) return kb.vision;
    if (q.includes("archit") || q.includes("api") || q.includes("gateway") || q.includes("secur") || q.includes("sécur") || q.includes("tek") || q.includes("koranabuhanga")) return kb.architecture;
    if (q.includes("health") || q.includes("sant") || q.includes("priva") || q.includes("donn") || q.includes("buzima") || q.includes("anga")) return kb.health;
    if (q.includes("model") || q.includes("algo") || q.includes("ai") || q.includes("machine") || q.includes("int")) return kb.model;
    if (q.includes("cons") || q.includes("perm") || q.includes("withdraw") || q.includes("retir") || q.includes("hagar") || q.includes("uruhushya") || q.includes("data") || q.includes("donn") || q.includes("amakuru")) return kb.consent_expl;
    if (q.includes("ethic") || q.includes("fair") || q.includes("bias") || q.includes("equit") || q.includes("biais") || q.includes("tabera")) return kb.ethics;
    if (q.includes("score") || q.includes("risk") || q.includes("risq") || q.includes("taux") || q.includes("rate") || q.includes("nota")) return kb.score_agent; // Default to agent explanation
    if (q.includes("why") || q.includes("pourquoi") || q.includes("refus") || q.includes("impamvu")) return kb.score_client;
    if (q.includes("tip") || q.includes("conseil") || q.includes("nama") || q.includes("prev") || q.includes("musa")) return kb.prevention;
    
    return kb.default;
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const userMsg = input;
    setMessages((prev) => [...prev, { role: "user", text: userMsg }]);
    setInput("");
    setIsTyping(true);

    // Simulate AI response delay
    setTimeout(() => {
      const responseText = getResponse(userMsg, lang);
      setMessages((prev) => [...prev, { role: "bot", text: responseText }]);
      setIsTyping(false);
    }, 1500);
  };

  return (
    <Card className="flex flex-col h-[500px] border-l-4 border-l-secondary shadow-xl">
      <CardHeader className="bg-primary/5 pb-4">
        <CardTitle className="flex items-center gap-3 text-lg">
          <Avatar className="h-10 w-10 border-2 border-white shadow-sm">
            <AvatarImage src={botAvatar} alt="AI" />
            <AvatarFallback>AI</AvatarFallback>
          </Avatar>
          <div>
            {t.title}
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
              </span>
              <span className="text-xs font-normal text-muted-foreground">Online • GPT-4o Model</span>
            </div>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 p-0 overflow-hidden">
        <ScrollArea className="h-full p-4">
          <div className="space-y-4">
            {messages.map((msg, i) => (
              <div
                key={i}
                className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm shadow-sm ${
                    msg.role === "user"
                      ? "bg-primary text-primary-foreground rounded-br-none"
                      : "bg-white dark:bg-muted text-foreground rounded-bl-none border border-border"
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-muted rounded-2xl rounded-bl-none px-4 py-3 border border-border flex gap-1 items-center">
                  <span className="w-2 h-2 bg-foreground/30 rounded-full animate-bounce"></span>
                  <span className="w-2 h-2 bg-foreground/30 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                  <span className="w-2 h-2 bg-foreground/30 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                </div>
              </div>
            )}
            <div ref={scrollRef} />
          </div>
        </ScrollArea>
      </CardContent>
      <CardFooter className="p-4 bg-background border-t">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex w-full gap-2"
        >
          <Input
            placeholder={t.placeholder}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="flex-1"
          />
          <Button type="submit" size="icon" disabled={!input.trim()}>
            <Send className="h-4 w-4" />
          </Button>
        </form>
      </CardFooter>
    </Card>
  );
}
