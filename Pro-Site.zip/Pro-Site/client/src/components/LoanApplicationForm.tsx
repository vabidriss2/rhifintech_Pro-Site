import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Progress } from "@/components/ui/progress";
import { Search, Loader2, CheckCircle2, AlertCircle, Smartphone, Heart, ArrowRight, ArrowLeft, Printer } from "lucide-react";
import { TRANSLATIONS } from "@/lib/constants";
import { toast } from "@/hooks/use-toast";

interface LoanApplicationFormProps {
  lang: "en" | "fr" | "rw";
}

// Validation Schema
const formSchema = z.object({
  nid: z.string().min(16, "NID must be 16 characters").max(16),
  phone: z.string().min(10, "Phone must be at least 10 digits"),
  firstname: z.string().min(2),
  lastname: z.string().min(2),
  amount: z.string().min(1),
  duration: z.string().min(1),
  purpose: z.string().min(3),
  income: z.string().min(1),
});

export default function LoanApplicationForm({ lang }: LoanApplicationFormProps) {
  const t = TRANSLATIONS[lang].agent_dashboard?.form || TRANSLATIONS["en"].agent_dashboard.form; // Fallback
  
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [consentStatus, setConsentStatus] = useState<"unknown" | "pending" | "valid">("unknown");
  const [scoreResult, setScoreResult] = useState<any>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      nid: "",
      phone: "",
      firstname: "",
      lastname: "",
      amount: "",
      duration: "",
      purpose: "",
      income: "",
    },
  });

  // Simulate Searching for Client
  const handleSearch = async () => {
    const nid = form.getValues("nid");
    if (nid.length < 16) {
      form.setError("nid", { message: "Invalid NID format" });
      return;
    }
    
    setIsLoading(true);
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Mock Data found
    form.setValue("firstname", "Jean-Paul");
    form.setValue("lastname", "Mugisha");
    form.setValue("phone", "0788123456");
    
    // Simulate Consent Check (Randomly false to show flow)
    setConsentStatus("pending"); 
    setIsLoading(false);
    setStep(2);
  };

  const requestConsent = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setConsentStatus("valid");
    setIsLoading(false);
    toast({
      title: t.actions.consent_sent,
      description: "Client confirmed via USSD *182#",
      variant: "default",
    });
  };

  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    setStep(3); // Assessment View
    setIsLoading(true);
    
    // Simulate Complex Scoring Process
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    setScoreResult({
      score: 785,
      risk: "Low",
      health_bonus: "+45 points",
      max_amount: "1,200,000 RWF",
      rate: "12%"
    });
    setIsLoading(false);
    setStep(4);
  };

  // Step 1: Identification
  if (step === 1) {
    return (
      <Card className="w-full max-w-2xl mx-auto border-t-4 border-t-primary shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <span className="bg-primary/10 text-primary w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">1</span>
            {t.steps.identify}
          </CardTitle>
          <CardDescription>Enter National ID to retrieve client history.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid gap-4">
             <div className="flex gap-4">
               <Input 
                 placeholder={t.fields.nid} 
                 className="flex-1 text-lg tracking-widest" 
                 maxLength={16}
                 {...form.register("nid")}
               />
               <Button onClick={handleSearch} disabled={isLoading} className="bg-primary hover:bg-primary/90">
                 {isLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                 <span className="ml-2">{t.actions.search}</span>
               </Button>
             </div>
             {form.formState.errors.nid && (
               <p className="text-sm text-destructive">{form.formState.errors.nid.message}</p>
             )}
          </div>
          
          <div className="bg-muted/30 p-4 rounded-lg border border-dashed text-center text-muted-foreground text-sm">
             System connected to NIDA (National ID Agency) Simulation
          </div>
        </CardContent>
      </Card>
    );
  }

  // Step 2: Consent & Details
  if (step === 2) {
    return (
      <Card className="w-full max-w-2xl mx-auto border-t-4 border-t-primary shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
             <span className="bg-primary/10 text-primary w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold">2</span>
             {t.steps.loan}
          </CardTitle>
          <CardDescription>Verify consent and enter loan details.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
           
           {/* Client Info Readonly */}
           <div className="grid grid-cols-2 gap-4 p-4 bg-muted/20 rounded-lg">
             <div>
               <label className="text-xs text-muted-foreground uppercase">Client</label>
               <p className="font-semibold text-lg">{form.getValues("firstname")} {form.getValues("lastname")}</p>
             </div>
             <div>
               <label className="text-xs text-muted-foreground uppercase">Phone</label>
               <p className="font-mono">{form.getValues("phone")}</p>
             </div>
           </div>

           {/* Consent Check */}
           {consentStatus === 'pending' ? (
             <Alert variant="destructive" className="bg-yellow-50 text-yellow-900 border-yellow-200 dark:bg-yellow-900/20 dark:text-yellow-200">
               <AlertCircle className="h-4 w-4 text-yellow-600" />
               <AlertTitle>{t.status.consent_needed}</AlertTitle>
               <AlertDescription className="mt-2 flex flex-col gap-2">
                 <p>Client has not authorized access to HIA (Health Indicators). Score will be lower.</p>
                 <Button size="sm" variant="outline" onClick={requestConsent} disabled={isLoading} className="w-fit border-yellow-600 text-yellow-700 hover:bg-yellow-100">
                   {isLoading ? <Loader2 className="h-3 w-3 animate-spin mr-2" /> : <Smartphone className="h-3 w-3 mr-2" />}
                   {t.actions.request_consent}
                 </Button>
               </AlertDescription>
             </Alert>
           ) : (
             <Alert className="bg-green-50 text-green-900 border-green-200 dark:bg-green-900/20 dark:text-green-200">
               <CheckCircle2 className="h-4 w-4 text-green-600" />
               <AlertTitle>{t.status.consent_valid}</AlertTitle>
               <AlertDescription>HIA Data will be included in scoring.</AlertDescription>
             </Alert>
           )}

           <Form {...form}>
             <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
               <div className="grid grid-cols-2 gap-4">
                 <FormField
                   control={form.control}
                   name="amount"
                   render={({ field }) => (
                     <FormItem>
                       <FormLabel>{t.fields.amount}</FormLabel>
                       <FormControl><Input placeholder="500,000" {...field} /></FormControl>
                       <FormMessage />
                     </FormItem>
                   )}
                 />
                 <FormField
                   control={form.control}
                   name="duration"
                   render={({ field }) => (
                     <FormItem>
                       <FormLabel>{t.fields.duration}</FormLabel>
                       <FormControl>
                         <Select onValueChange={field.onChange} defaultValue={field.value}>
                           <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                           <SelectContent>
                             <SelectItem value="3">3 Months</SelectItem>
                             <SelectItem value="6">6 Months</SelectItem>
                             <SelectItem value="12">12 Months</SelectItem>
                           </SelectContent>
                         </Select>
                       </FormControl>
                       <FormMessage />
                     </FormItem>
                   )}
                 />
               </div>
               
               <FormField
                 control={form.control}
                 name="purpose"
                 render={({ field }) => (
                   <FormItem>
                     <FormLabel>{t.fields.purpose}</FormLabel>
                     <FormControl><Input placeholder="e.g. Expand shop inventory" {...field} /></FormControl>
                     <FormMessage />
                   </FormItem>
                 )}
               />

               <div className="flex justify-between pt-4">
                 <Button variant="ghost" onClick={() => setStep(1)}>{t.actions.back}</Button>
                 <Button type="submit" className="bg-primary">
                   {t.actions.submit}
                   <ArrowRight className="ml-2 h-4 w-4" />
                 </Button>
               </div>
             </form>
           </Form>

        </CardContent>
      </Card>
    );
  }

  // Step 3: Loading / Assessment
  if (step === 3) {
    return (
       <Card className="w-full max-w-2xl mx-auto h-[400px] flex flex-col items-center justify-center text-center space-y-8 shadow-lg">
         <div className="relative">
           <div className="absolute inset-0 bg-primary/20 rounded-full blur-xl animate-pulse"></div>
           <Loader2 className="h-16 w-16 text-primary animate-spin relative z-10" />
         </div>
         <div className="space-y-2 max-w-md px-4">
           <h3 className="text-xl font-bold font-display">{t.status.fetching}</h3>
           <div className="space-y-4 pt-4 w-full">
             <div className="flex items-center justify-between text-sm text-muted-foreground">
               <span>Mobile Money API (MMA)</span>
               <CheckCircle2 className="h-4 w-4 text-green-500" />
             </div>
             <div className="flex items-center justify-between text-sm text-muted-foreground">
               <span>Health Indicators API (HIA)</span>
               <span className="flex items-center text-primary animate-pulse">Processing...</span>
             </div>
             <div className="flex items-center justify-between text-sm text-muted-foreground">
               <span>AI Risk Model (CSA)</span>
               <span>Waiting</span>
             </div>
           </div>
         </div>
       </Card>
    );
  }

  // Step 4: Result
  if (step === 4 && scoreResult) {
    return (
      <Card className="w-full max-w-2xl mx-auto border-t-4 border-t-secondary shadow-xl overflow-hidden printable-area">
        <div className="bg-secondary/10 p-6 text-center border-b border-secondary/20">
           <div className="flex justify-between items-center mb-4 no-print">
             <div className="text-xs text-muted-foreground">Loan Offer Ref: #RW-2025-VANTAGE</div>
             <div className="text-xs font-bold text-primary">OFFICIAL DOCUMENT</div>
           </div>
           <h2 className="text-sm font-bold uppercase tracking-widest text-secondary-foreground">{t.steps.result}</h2>
           <div className="mt-4 flex items-center justify-center gap-4">
             <div className="text-6xl font-display font-bold text-primary">{scoreResult.score}</div>
             <div className="text-left">
               <div className="text-sm text-muted-foreground">Vantage Score</div>
               <div className="font-bold text-green-600">{scoreResult.risk} Risk</div>
             </div>
           </div>
        </div>
        <CardContent className="p-6 space-y-6">
           <div className="grid grid-cols-2 gap-4">
             <div className="p-4 bg-muted/30 rounded-lg border">
               <div className="text-sm text-muted-foreground">Approved Amount</div>
               <div className="text-xl font-bold">{scoreResult.max_amount}</div>
             </div>
             <div className="p-4 bg-muted/30 rounded-lg border">
               <div className="text-sm text-muted-foreground">Interest Rate</div>
               <div className="text-xl font-bold text-secondary">{scoreResult.rate}</div>
               <div className="text-xs text-green-600 flex items-center gap-1">
                 <Heart className="h-3 w-3" />
                 {scoreResult.health_bonus}
               </div>
             </div>
           </div>

           <div className="space-y-4">
             <h4 className="font-semibold text-sm border-b pb-2">AI Recommendation</h4>
             <p className="text-sm text-muted-foreground leading-relaxed">
               Applicant demonstrates strong health adherence (HIA Score 85/100), significantly reducing default risk despite limited financial history. <strong className="text-foreground">Recommended for approval.</strong>
             </p>
           </div>
           
           <div className="hidden print:block mt-8 pt-8 border-t">
              <div className="flex justify-between text-xs text-gray-500">
                <div>
                  <p>Authorized Signature:</p>
                  <div className="h-12 border-b border-gray-300 w-48 mt-2"></div>
                </div>
                <div>
                  <p>Date: _________________</p>
                </div>
              </div>
              <p className="text-center text-[10px] mt-8 text-gray-400">Generated by Rwanda Vantage System. Valid for 48 hours.</p>
           </div>
        </CardContent>
        <CardFooter className="bg-muted/10 p-4 flex gap-4 justify-end no-print">
           <Button variant="outline" onClick={() => setStep(1)}>New Application</Button>
           <Button variant="outline" onClick={() => window.print()}>
             <Printer className="h-4 w-4 mr-2" />
             Print Offer
           </Button>
           <Button className="bg-primary">Proceed to Disburse</Button>
        </CardFooter>
      </Card>
    );
  }

  return null;
}
