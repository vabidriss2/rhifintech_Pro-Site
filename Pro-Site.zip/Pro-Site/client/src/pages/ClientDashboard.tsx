import { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Heart, Lock, ShieldCheck, FileCheck, AlertCircle } from "lucide-react";
import { TRANSLATIONS } from "@/lib/constants";
import { toast } from "@/hooks/use-toast";

export default function ClientDashboard() {
  const [lang, setLang] = useState<"en" | "fr" | "rw">("en");
  const [consentGiven, setConsentGiven] = useState(false);
  const t = TRANSLATIONS[lang].client_portal;

  const handleConsentToggle = (checked: boolean) => {
    setConsentGiven(checked);
    if (checked) {
      toast({
        title: lang === 'rw' ? "Uruhushya Rwatanzwe" : "Consent Granted",
        description: lang === 'rw' 
          ? "Amakuru yawe y'ubuzima agiye gufasha kuzamura amanota yawe." 
          : "Your health adherence data is now improving your credit score.",
        variant: "default",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background font-sans flex flex-col">
      <Navbar lang={lang} setLang={setLang} />
      
      <main className="flex-1 py-12 bg-muted/10">
        <div className="container px-4 md:px-6 space-y-8">
          
          {/* Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl font-display font-bold text-foreground">{t.title}</h1>
              <p className="text-muted-foreground">ID: #RW-8821-KGL | Jean-Paul M.</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="flex h-3 w-3 rounded-full bg-green-500"></span>
              <span className="text-sm font-medium text-muted-foreground">{t.status_active}</span>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            
            {/* Left Column: Health & Consent */}
            <div className="lg:col-span-2 space-y-8">
              
              {/* Consent Card */}
              <Card className="border-l-4 border-l-primary shadow-md">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ShieldCheck className="h-5 w-5 text-primary" />
                    {t.consent_title}
                  </CardTitle>
                  <CardDescription>
                    GDPR / KVPO Compliant
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/5 border border-secondary/20">
                    <div className="space-y-1 max-w-[80%]">
                      <p className="font-medium text-foreground">{t.consent_desc}</p>
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <Lock className="h-3 w-3" /> 
                        Encrypted & Anonymized (Token: #8821-HIA-SECURE)
                      </p>
                    </div>
                    <Switch 
                      checked={consentGiven}
                      onCheckedChange={handleConsentToggle}
                      className="data-[state=checked]:bg-secondary"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Health Score Card (Blurred if no consent) */}
              <Card className="relative overflow-hidden">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Heart className="h-5 w-5 text-red-500" />
                    {t.health_score} (HIA)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className={`transition-all duration-500 ${!consentGiven ? 'blur-md opacity-50 select-none' : ''}`}>
                    <div className="flex items-end gap-2 mb-2">
                      <span className="text-5xl font-bold text-foreground">85</span>
                      <span className="text-muted-foreground mb-1">/ 100</span>
                    </div>
                    <Progress value={85} className="h-3 bg-red-100 dark:bg-red-950 [&>div]:bg-red-500" />
                    <p className="mt-4 text-sm text-muted-foreground">
                      Excellent adherence! You picked up your last 3 prescriptions on time.
                    </p>
                  </div>
                  
                  {!consentGiven && (
                    <div className="absolute inset-0 flex items-center justify-center bg-background/50 backdrop-blur-[2px]">
                      <div className="text-center p-6 bg-card rounded-xl shadow-xl border max-w-xs">
                        <AlertCircle className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                        <p className="font-medium text-foreground mb-2">Data Privacy Locked</p>
                        <p className="text-xs text-muted-foreground mb-4">Enable consent above to view your score and reduce loan rates.</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

            </div>

            {/* Right Column: Loan Offers */}
            <div className="space-y-8">
              <Card className="h-full bg-primary text-primary-foreground border-none shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileCheck className="h-5 w-5" />
                    {t.offers}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  
                  {/* Active Offer */}
                  <div className="p-4 rounded-xl bg-white/10 border border-white/20 backdrop-blur-md">
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-xs font-semibold uppercase tracking-wider opacity-70">Micro-Business Loan</span>
                      <Badge variant="secondary" className="bg-secondary text-white border-none">Approved</Badge>
                    </div>
                    <div className="mb-4">
                       <span className="text-3xl font-bold">500,000 RWF</span>
                    </div>
                    
                    <div className="space-y-2 text-sm opacity-90">
                      <div className="flex justify-between">
                         <span>Interest Rate</span>
                         <span className={`font-bold ${consentGiven ? 'text-secondary' : ''}`}>
                           {consentGiven ? '12% (-3%)' : '15%'}
                         </span>
                      </div>
                      <div className="flex justify-between">
                         <span>Duration</span>
                         <span>6 Months</span>
                      </div>
                    </div>

                    {!consentGiven && (
                       <div className="mt-4 pt-4 border-t border-white/10 text-xs text-yellow-200 flex items-center gap-2">
                         <AlertCircle className="h-3 w-3" />
                         Enable health consent to save 3% interest!
                       </div>
                    )}
                  </div>

                  <Button className="w-full bg-white text-primary hover:bg-white/90 font-bold">
                    View Details
                  </Button>

                </CardContent>
              </Card>
            </div>

          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
