import { useState } from "react";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Features from "@/components/Features";
import Footer from "@/components/Footer";

export default function Home() {
  const [lang, setLang] = useState<"en" | "fr" | "rw">("en");

  return (
    <div className="min-h-screen bg-background font-sans text-foreground">
      <Navbar lang={lang} setLang={setLang} />
      <Hero lang={lang} />
      <Features lang={lang} />
      
      {/* Call to Action Section */}
      <section className="py-20 bg-primary text-primary-foreground">
        <div className="container px-4 text-center">
          <h2 className="text-3xl font-display font-bold mb-6">Ready to see the Prototype?</h2>
          <p className="max-w-2xl mx-auto mb-8 text-primary-foreground/80 text-lg">
            Explore the Agent Dashboard to see how health scores directly impact credit eligibility in real-time.
          </p>
          <a href="/dashboard" className="inline-flex h-12 items-center justify-center rounded-md bg-secondary px-8 text-sm font-medium text-white shadow transition-colors hover:bg-secondary/90 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50">
            Open Agent Dashboard
          </a>
        </div>
      </section>
      
      <Footer />
    </div>
  );
}
