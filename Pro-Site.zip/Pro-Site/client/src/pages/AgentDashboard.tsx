import { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ScoringSimulator from "@/components/ScoringSimulator";
import LoanApplicationForm from "@/components/LoanApplicationForm";
import AIAssistant from "@/components/AIAssistant";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TRANSLATIONS } from "@/lib/constants";
import { FilePlus, Activity, History, FileText, CheckCircle2, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export default function AgentDashboard() {
  const [lang, setLang] = useState<"en" | "fr" | "rw">("en");
  const t = TRANSLATIONS[lang].agent_dashboard || TRANSLATIONS["en"].agent_dashboard; // Fallback

  const historyData = [
    { id: "RW-8821", name: "Jean-Paul M.", amount: "500,000 RWF", status: "Approved", date: "Today, 10:45 AM", score: 785 },
    { id: "RW-9932", name: "Marie C.", amount: "1,200,000 RWF", status: "Pending", date: "Yesterday, 4:20 PM", score: 650 },
    { id: "RW-7741", name: "David K.", amount: "300,000 RWF", status: "Rejected", date: "12 Dec, 2025", score: 420 },
  ];

  return (
    <div className="min-h-screen bg-background font-sans text-foreground flex flex-col">
      <Navbar lang={lang} setLang={setLang} />
      
      <main className="flex-1 py-12 bg-muted/20">
        <div className="container px-4 md:px-6">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-display font-bold text-primary">{t.title}</h1>
              <p className="text-muted-foreground mt-1">{t.subtitle}</p>
            </div>
            <Badge variant="outline" className="px-4 py-1 border-primary/20 text-primary">
              <span className="w-2 h-2 rounded-full bg-green-500 mr-2"></span>
              System Active
            </Badge>
          </div>

          <div className="grid xl:grid-cols-3 gap-8">
            {/* Main Application Area */}
            <div className="xl:col-span-2 space-y-8">
              <Tabs defaultValue="new-app" className="w-full">
                <TabsList className="grid w-full grid-cols-3 mb-8">
                  <TabsTrigger value="new-app" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                    <FilePlus className="h-4 w-4 mr-2" />
                    {t.tabs.new_app}
                  </TabsTrigger>
                  <TabsTrigger value="simulator">
                    <Activity className="h-4 w-4 mr-2" />
                    {t.tabs.simulator}
                  </TabsTrigger>
                  <TabsTrigger value="history">
                    <History className="h-4 w-4 mr-2" />
                    {t.tabs.history}
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="new-app" className="mt-0">
                  <LoanApplicationForm lang={lang} />
                </TabsContent>
                
                <TabsContent value="simulator" className="mt-0">
                  <ScoringSimulator lang={lang} />
                </TabsContent>
                
                <TabsContent value="history" className="mt-0">
                  <div className="space-y-4">
                    {historyData.map((item) => (
                      <Card key={item.id} className="hover:shadow-md transition-shadow cursor-pointer">
                        <CardContent className="p-4 flex items-center justify-between">
                          <div className="flex items-center gap-4">
                            <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                              item.status === 'Approved' ? 'bg-green-100 text-green-700' :
                              item.status === 'Pending' ? 'bg-yellow-100 text-yellow-700' :
                              'bg-red-100 text-red-700'
                            }`}>
                              {item.status === 'Approved' ? <CheckCircle2 className="h-5 w-5" /> :
                               item.status === 'Pending' ? <Clock className="h-5 w-5" /> :
                               <FileText className="h-5 w-5" />
                              }
                            </div>
                            <div>
                              <p className="font-semibold text-foreground">{item.name}</p>
                              <p className="text-sm text-muted-foreground">ID: {item.id} • {item.date}</p>
                            </div>
                          </div>
                          <div className="text-right">
                             <p className="font-bold text-foreground">{item.amount}</p>
                             <div className="flex items-center justify-end gap-2 text-sm">
                               <span className={
                                 item.status === 'Approved' ? 'text-green-600' :
                                 item.status === 'Pending' ? 'text-yellow-600' :
                                 'text-red-600'
                               }>{item.status}</span>
                               <span className="text-muted-foreground">• Score: {item.score}</span>
                             </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </div>

            {/* Sidebar / Assistant */}
            <div className="xl:col-span-1">
               <div className="sticky top-24 space-y-6">
                 <div>
                   <h3 className="font-semibold mb-4 flex items-center gap-2">
                     <span className="bg-primary/10 p-1 rounded">🤖</span>
                     AI Support
                   </h3>
                   <AIAssistant lang={lang} />
                 </div>
                 
                 <div className="bg-blue-50 dark:bg-blue-950/30 p-4 rounded-xl border border-blue-100 dark:border-blue-900">
                    <h4 className="font-semibold text-blue-900 dark:text-blue-100 text-sm mb-2">Quick Tips</h4>
                    <ul className="text-xs text-blue-800 dark:text-blue-200 space-y-2 list-disc pl-4">
                      <li>Use Loan Application Form for new clients.</li>
                      <li>Simulator is for educational/demo purposes only.</li>
                      <li>Always verify NID via Irembo before processing.</li>
                    </ul>
                 </div>
               </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
