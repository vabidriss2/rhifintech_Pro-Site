import { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, Legend } from 'recharts';
import { Users, CreditCard, Activity, TrendingUp } from "lucide-react";
import { TRANSLATIONS } from "@/lib/constants";

// Mock Data for charts
const userGrowthData = [
  { name: 'Jan', users: 400, loans: 240 },
  { name: 'Feb', users: 500, loans: 300 },
  { name: 'Mar', users: 700, loans: 450 },
  { name: 'Apr', users: 850, loans: 580 },
  { name: 'May', users: 1200, loans: 900 },
];

const riskCorrelationData = [
  { group: 'Low Health Score', defaultRate: 15 },
  { group: 'Med Health Score', defaultRate: 8 },
  { group: 'High Health Score', defaultRate: 2 },
];

export default function AdminDashboard() {
  const [lang, setLang] = useState<"en" | "fr" | "rw">("en");
  const t = TRANSLATIONS[lang].admin_portal;

  return (
    <div className="min-h-screen bg-background font-sans flex flex-col">
      <Navbar lang={lang} setLang={setLang} />
      
      <main className="flex-1 py-12 bg-gray-50 dark:bg-gray-900/50">
        <div className="container px-4 md:px-6 space-y-8">
          
          <div className="mb-8">
            <h1 className="text-3xl font-display font-bold text-foreground">{t.title}</h1>
            <p className="text-muted-foreground">System Metrics & Performance Overview</p>
          </div>

          {/* Stats Row */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard icon={Users} title={t.stats.users} value="1,245" change="+12%" color="text-blue-500" />
            <StatCard icon={CreditCard} title={t.stats.loans} value="892" change="+18%" color="text-green-500" />
            <StatCard icon={Activity} title="HIA API Calls" value="54.2k" change="+5%" color="text-red-500" />
            <StatCard icon={TrendingUp} title="Repayment Rate" value="98.2%" change="+2.1%" color="text-purple-500" />
          </div>

          {/* Charts Row */}
          <div className="grid lg:grid-cols-2 gap-8">
            
            {/* Growth Chart */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle>Platform Growth</CardTitle>
                <CardDescription>User acquisition vs Loan issuance</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={userGrowthData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip 
                      contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                    />
                    <Legend />
                    <Bar dataKey="users" fill="hsl(215 100% 35%)" radius={[4, 4, 0, 0]} name="Users" />
                    <Bar dataKey="loans" fill="hsl(150 60% 45%)" radius={[4, 4, 0, 0]} name="Loans" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Risk Correlation Chart - The "Proof" of the project */}
            <Card className="shadow-sm border-l-4 border-l-secondary">
              <CardHeader>
                <CardTitle>{t.stats.health_impact}</CardTitle>
                <CardDescription>Correlation between Health Score & Default Risk (Simulated)</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={riskCorrelationData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="group" />
                    <YAxis unit="%" />
                    <Tooltip 
                      contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="defaultRate" 
                      stroke="hsl(0 84.2% 60.2%)" 
                      strokeWidth={3} 
                      dot={{ r: 6 }}
                      name="Loan Default Rate"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

        </div>
      </main>
      
      <Footer />
    </div>
  );
}

function StatCard({ icon: Icon, title, value, change, color }: any) {
  return (
    <Card>
      <CardContent className="p-6 flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <h3 className="text-2xl font-bold mt-1">{value}</h3>
          <p className="text-xs text-green-600 font-medium mt-1">{change} vs last month</p>
        </div>
        <div className={`p-3 rounded-full bg-muted/50 ${color}`}>
          <Icon className="h-6 w-6" />
        </div>
      </CardContent>
    </Card>
  )
}
