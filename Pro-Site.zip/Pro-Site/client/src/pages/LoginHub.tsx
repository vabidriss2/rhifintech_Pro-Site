import { useState } from "react";
import { Link } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { UserCircle2, Briefcase, ShieldAlert, ArrowRight } from "lucide-react";
import { TRANSLATIONS } from "@/lib/constants";
import { motion } from "framer-motion";

export default function LoginHub() {
  const [lang, setLang] = useState<"en" | "fr" | "rw">("en");
  const t = TRANSLATIONS[lang].roles;

  const roles = [
    {
      id: "agent",
      icon: Briefcase,
      title: t.agent.title,
      desc: t.agent.desc,
      link: "/dashboard",
      color: "text-primary",
      bg: "bg-primary/10",
      border: "border-primary/20"
    },
    {
      id: "client",
      icon: UserCircle2,
      title: t.client.title,
      desc: t.client.desc,
      link: "/client",
      color: "text-secondary",
      bg: "bg-secondary/10",
      border: "border-secondary/20"
    },
    {
      id: "admin",
      icon: ShieldAlert,
      title: t.admin.title,
      desc: t.admin.desc,
      link: "/admin",
      color: "text-accent-foreground",
      bg: "bg-accent/10",
      border: "border-accent/20"
    }
  ];

  return (
    <div className="min-h-screen bg-muted/20 font-sans flex flex-col">
      <Navbar lang={lang} setLang={setLang} />
      
      <main className="flex-1 container px-4 py-16 md:py-24 flex flex-col items-center justify-center">
        <div className="text-center mb-12 space-y-4">
          <h1 className="text-3xl md:text-5xl font-display font-bold text-foreground">{t.title}</h1>
          <p className="text-muted-foreground text-lg max-w-2xl">{t.subtitle}</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 w-full max-w-5xl">
          {roles.map((role, index) => {
            const Icon = role.icon;
            return (
              <motion.div
                key={role.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Link href={role.link}>
                  <Card className={`h-full cursor-pointer hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-2 ${role.border}`}>
                    <CardHeader className="text-center pt-8">
                      <div className={`mx-auto h-20 w-20 rounded-full flex items-center justify-center mb-4 ${role.bg}`}>
                        <Icon className={`h-10 w-10 ${role.color}`} />
                      </div>
                      <CardTitle className="text-xl font-bold">{role.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="text-center text-muted-foreground">
                      <p>{role.desc}</p>
                    </CardContent>
                    <CardFooter className="justify-center pb-8">
                      <Button variant="ghost" className={`group ${role.color}`}>
                        {role.id === 'agent' ? t.agent.cta : role.id === 'client' ? t.client.cta : t.admin.cta}
                        <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                      </Button>
                    </CardFooter>
                  </Card>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
